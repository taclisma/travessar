class End extends Phaser.Scene{
    constructor(){
        super("end");
    }

    create(){
        this.add.text(20,30, "booting");
        console.log("bbbbbbbbbbbbb");
        this.bg = this.add.tileSprite(0,0, config.width, config.height, "bg");
        this.bg.setOrigin(0,0);
       // this.load.image("telaFim", "assets/fim01.png");

        this.fim = this.add.image(config.width/2, config.height/2, "telaFim");

    }

}